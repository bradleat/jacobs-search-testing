inkibra-graph
=============

An abstraction layer running on top of redis that supports a semi-persistent and dynamically-indexable graph search.


